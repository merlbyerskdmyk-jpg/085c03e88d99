// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Play tinwhistle scale"); }
int main(){
  announce();
  return lionss_run_workload("tinwhistle");
}
