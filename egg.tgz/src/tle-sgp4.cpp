// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Propagate from TLE");
  std::fflush(stdout);
  return lionss_run_workload("tle-sgp4");
}
